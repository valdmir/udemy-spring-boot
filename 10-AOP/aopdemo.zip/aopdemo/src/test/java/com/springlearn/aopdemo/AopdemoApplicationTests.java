package com.springlearn.aopdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AopdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
