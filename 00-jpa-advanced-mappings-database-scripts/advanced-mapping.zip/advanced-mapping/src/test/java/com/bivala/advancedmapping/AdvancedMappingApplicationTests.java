package com.bivala.advancedmapping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvancedMappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
